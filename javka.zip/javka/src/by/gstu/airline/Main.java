package by.gstu.airline;

public class Main {
    public static void main(String[] arg) {

    }
}

