package by.gstu.airline.model.Brigade;

import by.gstu.airline.model.Entity;

import java.io.Serializable;
import java.sql.Date;

public class Brigade extends Entity implements Serializable {

    private String pilotsName;
    private String navigatorsName;
    private String stewardessName;
    private int dispetcherId;

    public Brigade() {
    }

    public Brigade( int id, String pilotsName, String navigatorsName, String stewardessName, int dispetcherId) {
            super(id);
            this.pilotsName = pilotsName;
            this.navigatorsName = navigatorsName;
            this.stewardessName = stewardessName;
            this.dispetcherId = dispetcherId;
    }

    public String getPilotsName() {
        return pilotsName;
    }

    public void setPilotsName(String pilotsName) {
        this.pilotsName = pilotsName;
    }

    public String getNavigatorsName() {
        return navigatorsName;
    }

    public void setNavigatorsName(String navigatorsName) { this.navigatorsName = navigatorsName; }

    public String getStewardessName() {
        return stewardessName;
    }

    public void setStewardessName(String stewardessName) { this.stewardessName = stewardessName; }

    public int getDispetcherId() {
        return dispetcherId;
    }

    public void setDispetcherId(int dispetcherId) { this.dispetcherId = dispetcherId; }

    public String toString() {
        return "Brigade #" + super.getId() + " Pilots " + pilotsName + " Navigators " + navigatorsName.toString() + " Stewardess " + stewardessName;
    }
}
