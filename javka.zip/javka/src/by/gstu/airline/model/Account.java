package by.gstu.airline.model;

import java.io.Serializable;

public class Account extends Entity implements Serializable {
    //to do ???
    //
}
