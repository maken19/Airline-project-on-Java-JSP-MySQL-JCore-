package by.gstu.airline.model.Employee.Member;

import by.gstu.airline.model.Employee.Employee;

public class Member extends Employee {
}
