package by.gstu.airline.model.Employee.Head;

import by.gstu.airline.model.Employee.Employee;

public class Administrator extends Head {
}
