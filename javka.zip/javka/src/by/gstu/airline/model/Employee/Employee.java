package by.gstu.airline.model.Employee;

import by.gstu.airline.model.Entity;

public class Employee extends Entity {
}
