package by.gstu.airline.model.Trip;

import by.gstu.airline.model.Entity;

import java.io.Serializable;
import java.sql.Date;

public class Trip extends Entity implements Serializable {

    private Date tripDate;
    private String tripName;
    private String aircraftName;
    private int administratorId;

    public Trip() {
    }

    public Trip (int id, Date tripDate, String tripName, String aircraftName, int administratorId) {
        super(id);
        this.tripDate = tripDate;
        this.tripName = tripName;
        this.aircraftName = aircraftName;
        this.administratorId = administratorId;
    }

    public Date getTripDate() {
        return tripDate;
    }

    public void setTripDate(Date tripDate) {
        this.tripDate = tripDate;
    }

    public String getAircraftName() {
        return aircraftName;
    }

    public void setCarName(String aircraftName) {
        this.aircraftName = aircraftName;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) { this.tripName = tripName; }

    public int getAdministratorId() {
        return administratorId;
    }

    public void setAdministratorId(int administratorId) { this.administratorId = administratorId; }



   public String toString() {
        return "Trip #" + super.getId() + " " + tripName + " date " + tripDate.toString() + ".Attached aircraft " + aircraftName;
   }


}
