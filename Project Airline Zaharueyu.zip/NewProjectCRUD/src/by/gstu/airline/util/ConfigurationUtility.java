package by.gstu.airline.util;

import java.util.ResourceBundle;

public class ConfigurationUtility {

    private static ConfigurationUtility instance;
    private static final ResourceBundle bundle = ResourceBundle.getBundle("resources.database");

    private ConfigurationUtility() {
    }

    synchronized public static ConfigurationUtility getInstance() {
        if (instance == null)
            instance = new ConfigurationUtility();
        return instance;
    }

    public String getValue(String key) {
        return bundle.getString(key);
    }
}
