package by.gstu.airline.util;

import java.util.Locale;
import java.util.ResourceBundle;

public class MessageUtility {
    private static final String RESOURCE_NAME = "resources.message";
    private static ResourceBundle bundle = ResourceBundle.getBundle(RESOURCE_NAME);
    private static MessageUtility instance;

    public MessageUtility() {
    }

    public static void changeResources(Locale locale) {
        bundle = ResourceBundle.getBundle(RESOURCE_NAME, locale);
    }

    public static String getMessage(String key) {
        return bundle.getString(key);
    }

    synchronized public static MessageUtility getInstance() {
        if (instance == null)
            instance = new MessageUtility();
        return instance;
    }
}
