package by.gstu.airline.util;

import java.util.ResourceBundle;

public class MappingUtility {

    private static MappingUtility instance;
    private static final ResourceBundle bundle = ResourceBundle.getBundle("resources.mapping");

    synchronized public static MappingUtility getInstance() {
        if (instance == null)
            instance = new MappingUtility();
        return instance;
    }

    private MappingUtility() {
    }

    public static String getPath(String key) {
        return bundle.getString(key);
    }
}
