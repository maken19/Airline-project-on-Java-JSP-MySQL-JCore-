package by.gstu.airline.util;

import java.util.Locale;
import java.util.ResourceBundle;

public class TranslateUtility {
    private static final String RESOURCE_NAME = "resources.translate";
    private static ResourceBundle bundle = ResourceBundle.getBundle(RESOURCE_NAME);
    private static TranslateUtility instance;


    private TranslateUtility() {
    }

    public static void changeResources(Locale locale) {
        bundle = ResourceBundle.getBundle(RESOURCE_NAME, locale);
    }

    public static String getValue(String key) {
        return bundle.getString(key);
    }

    synchronized public static TranslateUtility getInstance() {
        if (instance == null)
            instance = new TranslateUtility();
        return instance;
    }
}
