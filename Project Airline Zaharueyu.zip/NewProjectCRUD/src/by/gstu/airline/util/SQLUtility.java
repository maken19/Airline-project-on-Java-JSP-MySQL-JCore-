package by.gstu.airline.util;

import java.util.ResourceBundle;

public class SQLUtility {

    private static SQLUtility instance;
    private static final ResourceBundle bundle = ResourceBundle.getBundle("resources.sql");

    private SQLUtility() {
    }

    synchronized public static SQLUtility getInstance() {
        if (instance == null)
            instance = new SQLUtility();
        return instance;
    }

    public String getQuery(String query) {
        return bundle.getString(query);
    }
}
