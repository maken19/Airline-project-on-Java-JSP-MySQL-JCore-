package by.gstu.airline.enumeration;

public enum TripStatusEnum {
    PERFORMED, WAITING, DONE
}
