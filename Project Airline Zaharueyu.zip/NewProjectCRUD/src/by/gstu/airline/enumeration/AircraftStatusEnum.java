package by.gstu.airline.enumeration;

public enum AircraftStatusEnum {
    PERFORMED, WAITING, DONE
}
