package by.gstu.airline.enumeration;

import by.gstu.airline.command.*;

public enum CommandEnum {

    LOGIN {
        {
             this.command = new LoginCommand();
        }
    },
    EMPTY {
        {
            this.command = new EmptyCommand();
        }
    },
    ALL_AIRCRAFTS {
        {
            this.command = new ShowAllAircrafts();
        }
    },
    REGISTRATION {
        {
            this.command=new RegistrationCommand();
        }
    },
    LOGOUT {
        {
            this.command = new LogoutCommand();
        }
    },
    SHOW_AIRCRAFTS {
        {
            this.command = new ShowaAircraftsCommand();
        }
    },
    SHOW_MEMBERS{
        {
            this.command = new ShowMembersCommand();
        }
    },
    DELETE_TRIP{
        {
            this.command = new DeleteTripCommand();
        }
    },
    CREATE_AIRCRAFT{
        {
            this.command = new CreateAircraftCommand();
        }
    },
    CHANGE_LANG {
        {
            this.command = new ChangeLanguageCommand();
        }
    },
    SHOW_ADMINISTRATOR_TRIPS {
        {
            this.command = new ShowAdministratorTripsCommand();
        }
    },
    SHOW_BRIGADES {
        {
            this.command = new ShowBrigadesCommand();
        }
    },
    SHOW_AIRCRAFTS_WAITING{
        {
            this.command = new ShowAircraftsDispCommand();
        }
    },
    CREATE_TRIP {
        {
            this.command = new CreateTripCommand();
        }
    },
    CONFIRM_TRIP {
        {
            this.command = new ConfirmCommand();
        }
    },
    CLOSE_TRIP {
        {
            this.command = new CloseCommand();
        }
    };


    Command command;

    public Command getCurrentCommand() {
        return command;
    }
}
