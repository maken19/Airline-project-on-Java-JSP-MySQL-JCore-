package by.gstu.airline.enumeration;

public enum EmployeeStatusEnum {
    PILOT, NAVIGATOR, RADIOOPERATOR, STEWARDESS, ADMINISTRATOR, DISPETCHER, GUEST, MEMBER
}
