package by.gstu.airline.enumeration;

import by.gstu.airline.util.MappingUtility;

/**
 * Permissible links, which not blocking by PageRedirectFilter.
 */
public enum PermissibleLinksEnum {

    REGISTRATION_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            return MappingUtility.getPath(PATH_REGISTRATION_PAGE);
        }
    },
    LOGIN_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatusEnum) { return MappingUtility.getPath(PATH_LOGIN_PAGE);}
    },
    MAIN_DISPETCHER_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            if(employeeStatus == EmployeeStatusEnum.DISPETCHER) {
                return MappingUtility.getPath(PATH_MAIN_DISPETCHER_PAGE);
            }
            return null;
        }
    },
    MAIN_ADMINISTRATOR_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            if(employeeStatus == EmployeeStatusEnum.ADMINISTRATOR) {
                return MappingUtility.getPath(PATH_MAIN_ADMINISTRATOR_PAGE);
            }
            return null;
        }
    },
    ADMIN_TRIPS_PAGE_PATH {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            if(employeeStatus == EmployeeStatusEnum.ADMINISTRATOR) {
                return MappingUtility.getPath(PATH_MAIN_ADMINISTRATOR_PAGE);
            }
            return null;
        }
    },
    CLIENT_TRIPS_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            if (employeeStatus == EmployeeStatusEnum.DISPETCHER) {
                return MappingUtility.getPath(PATH_CLIENT_ORDERS);
            }
            return null;
        }
    },
    MEMBER_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            if (employeeStatus == EmployeeStatusEnum.MEMBER) {
                return MappingUtility.getPath(MEMBER_PAGE_PATH);
            }
            return null;
        }
    },
    ADMINISTRATOR_TRIPS_PAGE {
        public String getPath(EmployeeStatusEnum employeeStatus) {
            if (employeeStatus == EmployeeStatusEnum.ADMINISTRATOR) {
                return MappingUtility.getPath(PATH_ADMINISTRATOR_ORDERS);
            }
            return null;
        }
    };

    private static final String PATH_REGISTRATION_PAGE = "path.page.registration";
    private static final String PATH_LOGIN_PAGE ="path.page.login";
    private static final String PATH_MAIN_DISPETCHER_PAGE = "path.page.main.dispetcher";
    private static final String PATH_MAIN_ADMINISTRATOR_PAGE = "path.page.main.administrator";

    private static final String PATH_CLIENT_ORDERS = "path.page.client.orders";
    private static final String MEMBER_PAGE_PATH = "path.main.member.page";
    private static final String PATH_ADMINISTRATOR_ORDERS = "path.page.administrator.orders";

    public abstract String getPath(EmployeeStatusEnum employeeStatus);
}
