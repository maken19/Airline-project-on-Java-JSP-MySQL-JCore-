package by.gstu.airline.connect.DAO.mysqlDAOobjects;

import by.gstu.airline.connect.ConnectorDB;
import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.enumeration.EmployeeStatusEnum;
import by.gstu.airline.model.Employee.Employee;
import by.gstu.airline.util.CloseUtility;
import by.gstu.airline.util.SQLUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

//import static by.gstu.airline.enumeration.EmployeeStatusEnum.*;

public class MySQLEmployeeDAO implements EmployeeDAO {

    private static final Logger logger = LogManager.getLogger();

    /**
    * SQL queries, gets from sql.properties
    */
    private static final String SQL_SELECT_ALL_EMPLOYEES = "SELECT_ALL_EMPLOYEES";
    private static final String SQL_SELECT_EMPLOYEE_BY_ID = "SELECT_EMPLOYEE_BY_ID";
    private static final String SQL_SELECT_EMPLOYEE_BY_NAME = "SELECT_EMPLOYEE_BY_NAME";
    private static final String SQL_SELECT_EMPLOYEES_BY_BRIGADE = "SELECT_EMPLOYEES_BY_BRIGADE";
    private static final String SQL_SELECT_EMPLOYEE_BY_LOGIN = "SELECT_EMPLOYEE_BY_LOGIN";
    private static final String SQL_DELETE_EMPLOYEE_BY_ID = "DELETE_EMPLOYEE_BY_ID";
    private static final String SQL_INSERT_EMPLOYEE = "INSERT_EMPLOYEE";
    private static final String SQL_INSERT_EMPLOYEE_WITHOUT_IDBRIGADE = "INSERT_EMPLOYEE_WITHOUT_IDBRIGADE";
    private static final String SQL_UPDATE_EMPLOYEE = "UPDATE_EMPLOYEE";
    private static final String SQL_SELECT_MEMBER = "SELECT_MEMBER";
    private static final String SQL_INSERT_EMPLOYEE_LOGIN_PASSWORD = "INSERT_EMPLOYEE_LOGIN_PASSWORD";

    /**
    * Columns name
    */
    private static final String EMPLOYEE_ID = "employeeId";
    private static final String EMPLOYEE_NAME = "employeeName";
    private static final String EMPLOYEE_SURNAME = "employeeSurname";
    private static final String EMPLOYEE_STATUS = "status";
    private static final String LOGIN = "login";
    private static final String PASSWORD = "password";
    private static final String ID_BRIGADE = "idBrigade";

    /**
     * Gets connection from pool
     *
     * @return connection from pool
     */
    @Override
    public Connection getConnection() throws SQLException {
        Connection connection;
        connection = ConnectorDB.getInstance().getConnection();
        if(connection == null)
            throw new SQLException("Connection is null!");
        return connection;
    }

    public List<Employee> findAll() {
        List<Employee> employees = new ArrayList<>();
        Employee emp = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_ALL_EMPLOYEES), Statement.RETURN_GENERATED_KEYS);
            rs = st.executeQuery();
            while (rs.next()) {
                emp = new Employee();
                emp.setId(rs.getInt(EMPLOYEE_ID));
                emp.setEmployeeName(rs.getString(EMPLOYEE_NAME));
                emp.setEmployeeSurname(rs.getString(EMPLOYEE_SURNAME));
                emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)));
                emp.setLogin(rs.getString(LOGIN));
                emp.setPassword(rs.getString(PASSWORD));
                emp.setIdBrigade(rs.getInt(ID_BRIGADE));
                /*if (emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)) == null)) {
                   ;employees.add(emp);else emp.setIdBrigade(rs.getInt(ID_BRIGADE))
                }*/
                employees.add(emp);
            }
        } catch (SQLException e) {
            logger.error("Error while finding all employees.");
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return employees;
    }

    public List<Employee> getAllMembersAccount() {
        List<Employee> employees = new ArrayList<>();
        Employee emp = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_MEMBER), Statement.RETURN_GENERATED_KEYS);
            rs = st.executeQuery();
            while (rs.next()) {
                emp = new Employee();
                emp.setId(rs.getInt(EMPLOYEE_ID));
                emp.setEmployeeName(rs.getString(EMPLOYEE_NAME));
                emp.setEmployeeSurname(rs.getString(EMPLOYEE_SURNAME));
                emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)));
                emp.setLogin(rs.getString(LOGIN));
                emp.setPassword(rs.getString(PASSWORD));
                emp.setIdBrigade(rs.getInt(ID_BRIGADE));
                /*if (emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)) == null)) {
                   ;employees.add(emp);else emp.setIdBrigade(rs.getInt(ID_BRIGADE))
                }*/
                employees.add(emp);
            }
        } catch (SQLException e) {
            logger.error("Error while finding MEMBERS.");
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return employees;
    }

    @Override
    public Employee findEmployeeById(int id) {
        PreparedStatement st = null;
        Employee emp = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_EMPLOYEE_BY_ID));
            st.setLong(1, id);
            rs = st.executeQuery();
            while (rs.next()) {
                emp = new Employee();
                emp.setId(rs.getInt(EMPLOYEE_ID));
                emp.setEmployeeName(rs.getString(EMPLOYEE_NAME));
                emp.setEmployeeSurname(rs.getString(EMPLOYEE_SURNAME));
                emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)));
                emp.setLogin(rs.getString(LOGIN));
                emp.setPassword(rs.getString(PASSWORD));
                emp.setIdBrigade(rs.getInt(ID_BRIGADE));
                /*if (!emp.isDispatcher()) {
                    acc.setCarName(rs.getString(CAR));
                }*/
            }
            if (emp == null) {
                logger.warn("Can't find record with id [" + id + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding employee with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return emp;
    }

    @Override
    public Employee findEmployeeByName(String nam) {
        PreparedStatement st = null;
        Employee emp = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_EMPLOYEE_BY_NAME));
            st.setString(1, nam);
            rs = st.executeQuery();
            while (rs.next()) {
                emp = new Employee();
                emp.setId(rs.getInt(EMPLOYEE_ID));
                emp.setEmployeeName(rs.getString(EMPLOYEE_NAME));
                emp.setEmployeeSurname(rs.getString(EMPLOYEE_SURNAME));
                emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)));
                emp.setLogin(rs.getString(LOGIN));
                emp.setPassword(rs.getString(PASSWORD));
                emp.setIdBrigade(rs.getInt(ID_BRIGADE));
                /*if (!acc.isDispatcher()) {
                    acc.setCarName(rs.getString(CAR));
                }*/
            }
            if (emp == null) {
                logger.warn("Can't find record with name [" + nam + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding employee with name " + nam);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return emp;
    }

    public  Employee findEmployeeByLogin(String login) {
        PreparedStatement st = null;
        Employee emp = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_EMPLOYEE_BY_LOGIN));
            st.setString(1, login);
            rs = st.executeQuery();
            while (rs.next()) {
                emp = new Employee();
                emp.setId(rs.getInt(EMPLOYEE_ID));
                emp.setEmployeeName(rs.getString(EMPLOYEE_NAME));
                emp.setEmployeeSurname(rs.getString(EMPLOYEE_SURNAME));
                emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)));
                emp.setLogin(rs.getString(LOGIN));
                emp.setPassword(rs.getString(PASSWORD));
                emp.setIdBrigade(rs.getInt(ID_BRIGADE));
                /*if (emp.getStatus().DISPETCHER  true) {
                    emp.setCarName(rs.getString(CAR));
                }*/
            }
            if (emp == null) {
                logger.warn("Can't find record with login [" + login + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding account with login " + login);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return emp;
    }

    public List<Employee> findEmployeesByBrigade(int idBrigade) {
        List<Employee> employeesList = new ArrayList<>();
        PreparedStatement st = null;
        Employee emp = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_EMPLOYEES_BY_BRIGADE));
            st.setLong(1, idBrigade);
            rs = st.executeQuery();
            while (rs.next()) {
                emp = new Employee();
                emp.setId(rs.getInt(EMPLOYEE_ID));
                emp.setEmployeeName(rs.getString(EMPLOYEE_NAME));
                emp.setEmployeeSurname(rs.getString(EMPLOYEE_SURNAME));
                emp.setStatus(EmployeeStatusEnum.valueOf(rs.getString(EMPLOYEE_STATUS)));
                emp.setLogin(rs.getString(LOGIN));
                emp.setPassword(rs.getString(PASSWORD));
                emp.setIdBrigade(rs.getInt(ID_BRIGADE));
                /*if (!acc.isDispatcher()) {
                    acc.setCarName(rs.getString(CAR));
                }*/
                employeesList.add(emp);
            }
            if (employeesList == null) {
                logger.warn("Can't find records with idBrigade [" + idBrigade + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding employee with idBrigade " + idBrigade);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return employeesList;
    }

    @Override
    public boolean delete(int id) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_DELETE_EMPLOYEE_BY_ID));
            st.setInt(1, id);
            int result = st.executeUpdate();
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while deleting employee with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public boolean create(Employee employee) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_INSERT_EMPLOYEE), Statement.RETURN_GENERATED_KEYS);
            st.setString(1, employee.getEmployeeName());
            st.setString(2, employee.getEmployeeSurname());
            st.setString(3, employee.getStatus().toString());
            st.setString(4, employee.getLogin());
            st.setString(5, employee.getPassword());
            st.setInt(6, employee.getIdBrigade());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                employee.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating employee " + employee);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public boolean create2(Employee employee) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_INSERT_EMPLOYEE_WITHOUT_IDBRIGADE), Statement.RETURN_GENERATED_KEYS);
            st.setString(1, employee.getEmployeeName());
            st.setString(2, employee.getEmployeeSurname());
            st.setString(3, employee.getStatus().toString());
            st.setString(4, employee.getLogin());
            st.setString(5, employee.getPassword());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                employee.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating employee " + employee);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    public boolean create3(Employee employee) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_INSERT_EMPLOYEE_LOGIN_PASSWORD), Statement.RETURN_GENERATED_KEYS);
            st.setString(1, employee.getLogin());
            st.setString(2, employee.getPassword());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                employee.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating employee " + employee);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public Employee update(Employee employee) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_UPDATE_EMPLOYEE));
            st.setString(1, employee.getEmployeeName());
            st.setString(2, employee.getEmployeeSurname());
            st.setString(3, employee.getStatus().toString());
            st.setString(4, employee.getLogin());
            st.setString(5, employee.getPassword());
            st.setInt(6, employee.getId());
            st.executeUpdate();
            return employee;
        } catch (SQLException e) {
            logger.error("Error while updating employee " + employee);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return employee;
    }
}
