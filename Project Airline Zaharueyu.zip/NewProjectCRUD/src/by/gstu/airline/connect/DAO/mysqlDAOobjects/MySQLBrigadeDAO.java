package by.gstu.airline.connect.DAO.mysqlDAOobjects;

import by.gstu.airline.connect.ConnectorDB;
import by.gstu.airline.connect.DAO.BrigadeDAO;
import by.gstu.airline.model.Brigade.Brigade;
import by.gstu.airline.util.CloseUtility;
import by.gstu.airline.util.SQLUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLBrigadeDAO implements BrigadeDAO {

    private static final Logger logger = LogManager.getLogger();

    /**
     * SQL queries, gets from sql.properties
     */
    private static final String SELECT_ALL_BRIGADES = "SELECT_ALL_BRIGADES";
    private static final String SELECT_BRIGADE_BY_NAME = "SELECT_BRIGADE_BY_NAME";
    private static final String SELECT_BRIGADE_BY_ID = "SELECT_BRIGADE_BY_ID";
    private static final String DELETE_BRIGADE_BY_ID = "DELETE_BRIGADE_BY_ID";
    private static final String INSERT_BRIGADE = "INSERT_BRIGADE";
    private static final String UPDATE_BRIGADE = "UPDATE_BRIGADE";

    /**
     * Columns name
     */
    private static final String BRIGADE_ID = "brigadeId";
    private static final String BRIGADE_NAME = "brigadeName";

    /**
     * Gets connection from pool
     *
     * @return connection from pool
     */
    @Override
    public Connection getConnection() throws SQLException {
        Connection connection;
        connection = ConnectorDB.getInstance().getConnection();
        if(connection == null)
            throw new SQLException("Connection is null!");
        return connection;
    }

    public List<Brigade> findAll() {
        List<Brigade> brigades = new ArrayList<>();
        Brigade brig = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SELECT_ALL_BRIGADES), Statement.RETURN_GENERATED_KEYS);
            rs = st.executeQuery();
            while (rs.next()) {
                brig = new Brigade();
                brig.setId(rs.getInt(BRIGADE_ID));
                brig.setBrigadeName(rs.getString(BRIGADE_NAME));
                brigades.add(brig);
            }
        } catch (SQLException e) {
            logger.error("Error while finding all brigades.");
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return brigades;
    }

    public Brigade findBrigadeById(int id) {
        PreparedStatement st = null;
        Brigade brig = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SELECT_BRIGADE_BY_ID));
            st.setLong(1, id);
            rs = st.executeQuery();
            while (rs.next()) {
                brig = new Brigade();
                brig.setId(rs.getInt(BRIGADE_ID));
                brig.setBrigadeName(rs.getString(BRIGADE_NAME));
            }
            if (brig == null) {
                logger.warn("Can't find record with id [" + id + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding brigade with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return brig;
    }

    @Override
    public Brigade findBrigadeByName(String name) {
        PreparedStatement st = null;
        Brigade brig = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SELECT_BRIGADE_BY_NAME));
            st.setString(1, name);
            rs = st.executeQuery();
            while (rs.next()) {
                brig = new Brigade();
                brig.setId(rs.getInt(BRIGADE_ID));
                brig.setBrigadeName(rs.getString(BRIGADE_NAME));
            }
            if (brig == null) {
                logger.warn("Can't find record with name [" + name + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding employee with name " + name);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return brig;
    }

    @Override
    public boolean delete(int id) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(DELETE_BRIGADE_BY_ID));
            st.setInt(1, id);
            int result = st.executeUpdate();
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while deleting brigade with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public boolean create(Brigade brigade) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(INSERT_BRIGADE), Statement.RETURN_GENERATED_KEYS);
            st.setString(1, brigade.getBrigadeName());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                brigade.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating brigade " + brigade);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    public Brigade update(Brigade brigade) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(UPDATE_BRIGADE));
            st.setString(1, brigade.getBrigadeName());
            st.setInt(2, brigade.getId());
            st.executeUpdate();
            return brigade;
        } catch (SQLException e) {
            logger.error("Error while updating brigade " + brigade);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return brigade;
    }
}
