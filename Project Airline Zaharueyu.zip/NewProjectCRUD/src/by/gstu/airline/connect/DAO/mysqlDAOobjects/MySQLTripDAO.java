package by.gstu.airline.connect.DAO.mysqlDAOobjects;

import by.gstu.airline.connect.ConnectorDB;
import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.enumeration.TripStatusEnum;
import by.gstu.airline.model.Trip.Trip;
import by.gstu.airline.util.CloseUtility;
import by.gstu.airline.util.SQLUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MySQLTripDAO implements TripDAO {

    private static final Logger logger = LogManager.getLogger();

    /**
     * SQL queries, gets from sql.properties
     */
    private static final String SQL_SELECT_ALL_TRIPS = "SELECT_ALL_TRIPS";
    private static final String SQL_SELECT_TRIP_BY_ID = "SELECT_TRIP_BY_ID";
    private static final String SQL_SELECT_TRIP_BY_NAME = "SELECT_TRIP_BY_NAME";
    private static final String SQL_SELECT_TRIPS_BY_DATE = "SELECT_TRIPS_BY_DATE";
    private static final String SQL_DELETE_TRIP_BY_ID = "DELETE_TRIP_BY_ID";
    private static final String SQL_INSERT_TRIP = "INSERT_TRIP";
    private static final String SQL_UPDATE_TRIP = "UPDATE_TRIP";

    /**
     * Columns name
     */
    private static final String TRIP_ID = "tripId";
    private static final String TRIP_DATE = "tripDate";
    private static final String TRIP_NAME = "tripName";
    private static final String TRIP_STATUS = "status";

    /**
     * Gets connection from pool
     *
     * @return connection from pool
     */
    @Override
    public Connection getConnection() throws SQLException {
        Connection connection;
        connection = ConnectorDB.getInstance().getConnection();
        if(connection == null)
            throw new SQLException("Connection is null!");
        return connection;
    }

    public List<Trip> findAll() {
        List<Trip> trips = new ArrayList<>();
        Trip trip = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_ALL_TRIPS), Statement.RETURN_GENERATED_KEYS);
            rs = st.executeQuery();
            while (rs.next()) {
                trip = new Trip();
                trip.setId(rs.getInt(TRIP_ID));
                trip.setTripDate(rs.getDate(TRIP_DATE));
                trip.setTripName(rs.getString(TRIP_NAME));
                trip.setStatus(TripStatusEnum.valueOf((rs.getString(TRIP_STATUS))));
                trips.add(trip);
            }
        } catch (SQLException e) {
            logger.error("Error while finding all trips.");
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return trips;
    }

    @Override
    public Trip findTripById(int id) {
        PreparedStatement st = null;
        Trip trip = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_TRIP_BY_ID));
            st.setLong(1, id);
            rs = st.executeQuery();
            while (rs.next()) {
                trip = new Trip();
                trip.setId(rs.getInt(TRIP_ID));
                trip.setTripDate(rs.getDate(TRIP_DATE));
                trip.setTripName(rs.getString(TRIP_NAME));
                trip.setStatus(TripStatusEnum.valueOf((rs.getString(TRIP_STATUS))));
            }
            if (trip == null) {
                logger.warn("Can't find record with id [" + id + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding trip with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return trip;
    }

    @Override
    public Trip findTripByName(String nameTr) {
        PreparedStatement st = null;
        Trip trip = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_TRIP_BY_NAME));
            st.setString(1, nameTr);
            rs = st.executeQuery();
            while (rs.next()) {
                trip = new Trip();
                trip.setId(rs.getInt(TRIP_ID));
                trip.setTripDate(rs.getDate(TRIP_DATE));
                trip.setTripName(rs.getString(TRIP_NAME));
                trip.setStatus(TripStatusEnum.valueOf((rs.getString(TRIP_STATUS))));
            }
            if (trip == null) {
                logger.warn("Can't find record with name [" + nameTr + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding trip with name " + nameTr);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return trip;
    }

    public  List<Trip> findTripsByDate (Date date) {
        List<Trip> trips = new ArrayList<>();
        PreparedStatement st = null;
        Trip trip = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_TRIPS_BY_DATE));
            st.setDate(1, (java.sql.Date) date);
            rs = st.executeQuery();
            while (rs.next()) {
                trip = new Trip();
                trip.setId(rs.getInt(TRIP_ID));
                trip.setTripDate(rs.getDate(TRIP_DATE));
                trip.setTripName(rs.getString(TRIP_NAME));
                trip.setStatus(TripStatusEnum.valueOf((rs.getString(TRIP_STATUS))));
                trips.add(trip);
            }
            if (trips == null) {
                logger.warn("Can't find record with date [" + date + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding trip with date " + date);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return trips;
    }

    @Override
    public boolean delete(int id) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_DELETE_TRIP_BY_ID));
            st.setInt(1, id);
            int result = st.executeUpdate();
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while deleting trip with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public boolean create(Trip trip) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_INSERT_TRIP), Statement.RETURN_GENERATED_KEYS);
            st.setDate(1, trip.getTripDate());
            st.setString(2, trip.getTripName());
            st.setString(3, trip.getStatus().toString());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                trip.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating trip " + trip);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public Trip update(Trip trip) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_UPDATE_TRIP));
            st.setDate(1, trip.getTripDate());
            st.setString(2, trip.getTripName());
            st.setString(3, trip.getStatus().toString());
            st.setInt(4, trip.getId());
            st.executeUpdate();
            return trip;
        } catch (SQLException e) {
            logger.error("Error while updating trip " + trip);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return trip;
    }
}
