package by.gstu.airline.connect.DAO;

import by.gstu.airline.model.Trip.Trip;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public interface TripDAO {

    Connection getConnection() throws SQLException;

    List<Trip> findAll();

    Trip findTripById(int id);

    Trip findTripByName(String nameTr);

    List<Trip> findTripsByDate(Date date);

    boolean delete(int id);

    boolean create(Trip trip);

    Trip update(Trip trip);
}
