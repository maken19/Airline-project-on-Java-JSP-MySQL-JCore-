package by.gstu.airline.connect.DAO;

import by.gstu.airline.model.Aircraft.Aircraft;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface AircraftDAO {

    Connection getConnection() throws SQLException;

    List<Aircraft> findAll();

    Aircraft findAircraftById(int id);

    Aircraft findAircraftByName(String name);

    boolean delete(int id);

    boolean create(Aircraft aircraft);

    boolean create2(Aircraft aircraft);

    Aircraft update(Aircraft aircraft);

    //List<Administrator> getAllDriversAccount();//????только для адмиина????
    //Administrator findAccountByCar(String carName);
}
