package by.gstu.airline.connect.DAO;

import by.gstu.airline.model.Employee.Employee;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface EmployeeDAO {

    Connection getConnection() throws SQLException;

    List<Employee> findAll();

    Employee findEmployeeById(int id);

    Employee findEmployeeByName(String nam);

    List<Employee> findEmployeesByBrigade(int idBrigade);

    List<Employee> getAllMembersAccount();

    Employee findEmployeeByLogin(String login);

    boolean delete(int id);

    boolean create(Employee employee);

    boolean create2(Employee employee);

    boolean create3(Employee employee);

    Employee update(Employee employee);
}
