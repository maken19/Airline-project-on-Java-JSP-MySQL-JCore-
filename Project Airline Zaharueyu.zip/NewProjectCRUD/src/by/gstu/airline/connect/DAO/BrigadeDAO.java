package by.gstu.airline.connect.DAO;

import by.gstu.airline.model.Brigade.Brigade;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface BrigadeDAO {

    Connection getConnection() throws SQLException;

    List<Brigade> findAll();

    Brigade findBrigadeById(int id);

    Brigade findBrigadeByName(String name);

    boolean delete(int id);

    //boolean delete(Brigade brigade);

    boolean create(Brigade brigade);

    Brigade update(Brigade brigade);
}
