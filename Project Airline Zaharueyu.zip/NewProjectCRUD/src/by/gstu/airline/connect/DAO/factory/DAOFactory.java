package by.gstu.airline.connect.DAO.factory;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.BrigadeDAO;
import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.connect.DAO.TripDAO;

public abstract class DAOFactory {
    public static final int MYSQL = 1;

    public abstract TripDAO getTripDAO();

    public abstract BrigadeDAO getBrigadeDAO();

    public abstract EmployeeDAO getEmployeeDAO();

    public abstract AircraftDAO getAircraftDAO();

    public static DAOFactory getDAOFactory(int factoryNum) {
        switch (factoryNum) {
            case MYSQL:
                return new MySQLDAOFactory();
            default:
                throw new NullPointerException("No available factory.");
        }
    }
}
