package by.gstu.airline.connect.DAO.factory;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.BrigadeDAO;
import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.mysqlDAOobjects.MySQLAircraftDAO;
import by.gstu.airline.connect.DAO.mysqlDAOobjects.MySQLBrigadeDAO;
import by.gstu.airline.connect.DAO.mysqlDAOobjects.MySQLEmployeeDAO;
import by.gstu.airline.connect.DAO.mysqlDAOobjects.MySQLTripDAO;

public class MySQLDAOFactory extends DAOFactory {

    public TripDAO getTripDAO() {
        return new MySQLTripDAO();
    }

    public BrigadeDAO getBrigadeDAO() {
        return new MySQLBrigadeDAO();
    }

    public EmployeeDAO getEmployeeDAO() {
        return new MySQLEmployeeDAO();
    }

    public AircraftDAO getAircraftDAO() {
        return new MySQLAircraftDAO();
    }

}
