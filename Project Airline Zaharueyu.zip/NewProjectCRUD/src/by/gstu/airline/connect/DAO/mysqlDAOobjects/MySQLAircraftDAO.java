package by.gstu.airline.connect.DAO.mysqlDAOobjects;

import by.gstu.airline.connect.ConnectorDB;
import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.enumeration.AircraftStatusEnum;
import by.gstu.airline.model.Aircraft.Aircraft;
import by.gstu.airline.util.CloseUtility;
import by.gstu.airline.util.SQLUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLAircraftDAO implements AircraftDAO {

    private static final Logger logger = LogManager.getLogger();

    /**
     * SQL queries, gets from sql.properties
     */
    private static final String SQL_SELECT_ALL_AIRCRAFTS = "SELECT_ALL_AIRCRAFTS";
    private static final String SQL_SELECT_AIRCRAFT_BY_ID = "SELECT_AIRCRAFT_BY_ID";
    private static final String SQL_SELECT_AIRCRAFTS_BY_NAME = "SELECT_AIRCRAFTS_BY_NAME";
    private static final String SQL_DELETE_AIRCRAFT_BY_ID = "DELETE_AIRCRAFT_BY_ID";
    private static final String SQL_INSERT_AIRCRAFT = "INSERT_AIRCRAFT";
    private static final String SQL_INSERT_AIRCRAFT_WITHOUT_TRIPANDBRIGADES = "INSERT_AIRCRAFT_WITHOUT_TRIPANDBRIGADES";
    private static final String SQL_UPDATE_AIRCRAFT = "UPDATE_AIRCRAFT";

    /**
     * Columns name
     */
    private static final String AIRCRAFT_ID = "aircraftId";
    private static final String AIRCRAFT_NAME = "aircraftName";
    private static final String AIRCRAFT_STATUS = "status";
    private static final String CAPACITY = "capacity";
    private static final String ID_TRIP = "idTrip";
    private static final String BRIGADE_ID1 = "brigades_brigadeId1";

    /**
     * Gets connection from pool
     *
     * @return connection from pool
     */
    @Override
    public Connection getConnection() throws SQLException {
        Connection connection;
        connection = ConnectorDB.getInstance().getConnection();
        if(connection == null)
            throw new SQLException("Connection is null!");
        return connection;
    }

    public List<Aircraft> findAll() {
        List<Aircraft> aircrafts = new ArrayList<>();
        Aircraft air = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_ALL_AIRCRAFTS), Statement.RETURN_GENERATED_KEYS);
            rs = st.executeQuery();
            while (rs.next()) {
                air = new Aircraft();
                air.setId(rs.getInt(AIRCRAFT_ID));
                air.setAircraftName(rs.getString(AIRCRAFT_NAME));
                air.setStatus(AircraftStatusEnum.valueOf(rs.getString(AIRCRAFT_STATUS)));
                air.setCapacity(rs.getDouble(CAPACITY));
                air.setIdTrip(rs.getInt(ID_TRIP));
                air.setIdBrigade(rs.getInt(BRIGADE_ID1));
                aircrafts.add(air);
            }
        } catch (SQLException e) {
            logger.error("Error while finding all aircrafts.");
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return aircrafts;
    }

    @Override
    public Aircraft findAircraftById(int id) {
        PreparedStatement st = null;
        Aircraft air = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_AIRCRAFT_BY_ID));
            st.setLong(1, id);
            rs = st.executeQuery();
            while (rs.next()) {
                air = new Aircraft();
                air.setId(rs.getInt(AIRCRAFT_ID));
                air.setAircraftName(rs.getString(AIRCRAFT_NAME));
                air.setStatus(AircraftStatusEnum.valueOf(rs.getString(AIRCRAFT_STATUS)));
                air.setCapacity(rs.getDouble(CAPACITY));
                air.setIdTrip(rs.getInt(ID_TRIP));
                air.setIdBrigade(rs.getInt(BRIGADE_ID1));
            }
            if (air == null) {
                logger.warn("Can't find record with id [" + id + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding aircraft with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return air;
    }

    @Override
    public Aircraft findAircraftByName(String name) {
        PreparedStatement st = null;
        Aircraft air = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_SELECT_AIRCRAFTS_BY_NAME));
            st.setString(1, name);
            rs = st.executeQuery();
            while (rs.next()) {
                air = new Aircraft();
                air.setId(rs.getInt(AIRCRAFT_ID));
                air.setAircraftName(rs.getString(AIRCRAFT_NAME));
                air.setStatus(AircraftStatusEnum.valueOf(rs.getString(AIRCRAFT_STATUS)));
                air.setCapacity(rs.getDouble(CAPACITY));
                air.setIdTrip(rs.getInt(ID_TRIP));
                air.setIdBrigade(rs.getInt(BRIGADE_ID1));
            }
            if (air == null) {
                logger.warn("Can't find record with name [" + name + "]!");
            }
        } catch (SQLException e) {
            logger.error("Error while finding aircraft with name " + name);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return air;
    }

    @Override
    public boolean delete(int id) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_DELETE_AIRCRAFT_BY_ID));
            st.setInt(1, id);
            int result = st.executeUpdate();
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while deleting aircraft with id " + id);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public boolean create(Aircraft aircraft) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_INSERT_AIRCRAFT), Statement.RETURN_GENERATED_KEYS);
            st.setString(1, aircraft.getAircraftName());
            st.setString(2, aircraft.getStatus().toString());
            st.setDouble(3, aircraft.getCapacity());
            st.setInt(4, aircraft.getIdTrip());
            st.setInt(5, aircraft.getIdBrigade());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                aircraft.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating aircraft " + aircraft);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public boolean create2(Aircraft aircraft) {
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_INSERT_AIRCRAFT_WITHOUT_TRIPANDBRIGADES), Statement.RETURN_GENERATED_KEYS);
            st.setString(1, aircraft.getAircraftName());
            st.setString(2, aircraft.getStatus().toString());
            st.setDouble(3, aircraft.getCapacity());
            int result = st.executeUpdate();
            rs = st.getGeneratedKeys();
            while (rs.next()) {
                logger.trace(rs.getInt(1));
                aircraft.setId(rs.getInt(1));
            }
            if (result != 0)
                return true;
        } catch (SQLException e) {
            logger.error("Error while creating aircraft " + aircraft);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (rs != null)
                CloseUtility.getInstance().close(rs);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return false;
    }

    @Override
    public Aircraft update(Aircraft aircraft) {
        PreparedStatement st = null;
        Connection connection = null;
        try {
            connection = getConnection();
            st = connection.prepareStatement(SQLUtility.getInstance().getQuery(SQL_UPDATE_AIRCRAFT));
            st.setString(1, aircraft.getAircraftName());
            st.setString(2, aircraft.getStatus().toString());
            st.setDouble(3, aircraft.getCapacity());
            st.setInt(4, aircraft.getIdTrip());
            st.setInt(5, aircraft.getIdBrigade());
            st.setInt(6, aircraft.getId());
            st.executeUpdate();
            return aircraft;
        } catch (SQLException e) {
            logger.error("Error while updating aircraft " + aircraft);
            logger.error(e.getMessage());
        } finally {
            if (st != null)
                CloseUtility.getInstance().close(st);
            if (connection != null)
                CloseUtility.getInstance().close(connection);
        }
        return aircraft;
    }
}
