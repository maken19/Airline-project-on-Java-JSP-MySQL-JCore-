package by.gstu.airline.filter;

import by.gstu.airline.enumeration.EmployeeStatusEnum;
import by.gstu.airline.enumeration.PermissibleLinksEnum;
import by.gstu.airline.util.MappingUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "PageRedirectFilter", urlPatterns = {"/jsp/*"}, initParams = {@WebInitParam(name = "INDEX_PATH", value = "/index.jsp")})
public class PageRedirectFilter implements Filter {
    private static final Logger logger = LogManager.getLogger();
    private String indexPath;
    private static final String PARAM_USER = "user";
    private static final String PARAM_CLIENT_TYPE = "clientType";
    private static final String PATH_MAIN_DISPETCHER_PAGE = "path.page.main.dispetcher";
    private static final String PATH_MAIN_ADMINISTRATOR_PAGE = "path.page.main.administrator";

    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest httpRequest = (HttpServletRequest) req;
        HttpServletResponse httpResponse = (HttpServletResponse) resp;
        HttpSession session = httpRequest.getSession(false);
        String user = (String) session.getAttribute(PARAM_USER);
        EmployeeStatusEnum employeeStatus = (EmployeeStatusEnum)


                session.getAttribute(PARAM_CLIENT_TYPE);
        String page = httpRequest.getRequestURI();

        if (employeeStatus == null) {
            employeeStatus = EmployeeStatusEnum.DISPETCHER;
            session.setAttribute(PARAM_CLIENT_TYPE, employeeStatus);
        }
        logger.trace(user + " with status " + employeeStatus.name() + " try to visit page " + page);

        if (employeeStatus == EmployeeStatusEnum.ADMINISTRATOR) {
            if (!isPermissible(page, httpRequest.getContextPath(), employeeStatus)) {
                httpResponse.sendRedirect(httpRequest.getContextPath() + MappingUtility.getPath(PATH_MAIN_ADMINISTRATOR_PAGE));
            }
        } else if (employeeStatus == EmployeeStatusEnum.DISPETCHER) {
            if (!isPermissible(page, httpRequest.getContextPath(), employeeStatus)) {
                httpResponse.sendRedirect(httpRequest.getContextPath() + MappingUtility.getPath(PATH_MAIN_DISPETCHER_PAGE));
            }
        }
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {
        indexPath = config.getInitParameter("INDEX_PATH");
    }

    private boolean isPermissible(String link, String context, EmployeeStatusEnum employeeStatus) {
        String path;
        for (PermissibleLinksEnum permissibleLink : PermissibleLinksEnum.values()) {
            path = context + permissibleLink.getPath(employeeStatus);
            if (link.equals(path)) {
                return true;
            }
        }
        return false;
    }
}
