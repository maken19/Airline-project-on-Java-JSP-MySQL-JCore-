package by.gstu.airline.helper;

import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.enumeration.EmployeeStatusEnum;
import by.gstu.airline.model.Employee.Employee;

import java.util.function.Predicate;

public class LoginHelper  {

    private static LoginHelper instance;

    private LoginHelper() {
    }

    synchronized public static LoginHelper getInstance() {
        if (instance == null)
            instance = new LoginHelper();
        return instance;
    }

    /**
     * Check account by login and password
     *
     * @param login    - login
     * @param password - password
     * @return true - if account is found , false - if account isn't found
     */
    public boolean checkAccount(String login, String password) {
        DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
        EmployeeDAO employeeDAO = mySql.getEmployeeDAO();
        return employeeDAO.findAll()
                .stream()
                .anyMatch(isAccountSuitable(login, password));
    }

    /**
     * Check account by login
     *
     * @param login - login
     * @return true - if account is found , false - if account isn't found
     */
    public boolean checkLogin(String login) {
        DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
        EmployeeDAO employeeDAO = mySql.getEmployeeDAO();
        return employeeDAO.findAll()
                .stream()
                .anyMatch(isAccountSuitable(login));
    }

    private static Predicate<Employee> isAccountSuitable(String login, String password) {
        return acc -> acc.getLogin().equals(login) && acc.getPassword().equals(password);
    }

    private static Predicate<Employee> isAccountSuitable(String login) {
        return acc -> acc.getLogin().equals(login);
    }

    public static boolean isMember(final Employee employee) {
        return !EmployeeStatusEnum.DISPETCHER.equals(employee.getStatus()) && !EmployeeStatusEnum.ADMINISTRATOR.equals(employee.getStatus());
    }

    public static boolean isAdministrator(final Employee employee) {
        if (EmployeeStatusEnum.ADMINISTRATOR.equals(employee.getStatus()))
            return true;
        else return false;
    }

    public static boolean isDispetcher(final Employee employee) {
        if (EmployeeStatusEnum.DISPETCHER.equals(employee.getStatus()))
            return true;
        else return false;
    }
}
