package by.gstu.airline.model.Employee;


import by.gstu.airline.enumeration.EmployeeStatusEnum;
import by.gstu.airline.model.Entity;

import java.io.Serializable;
import java.util.Objects;

public class Employee extends Entity implements Serializable {

    private String employeeName;
    private String employeeSurname;
    private EmployeeStatusEnum status;
    private String login;
    private String password;
    private Integer idBrigade;

    public Employee(){

    }

    public Employee(int id, String employeeName, String employeeSurname, EmployeeStatusEnum status, String login, String password, int idBrigade){
        super(id);
        this.employeeName = employeeName;
        this.employeeSurname = employeeSurname;
        this.status = status;
        this.login = login;
        this.password = password;
        this.idBrigade = idBrigade;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeSurname() {
        return employeeSurname;
    }

    public void setEmployeeSurname(String employeeSurname) {
        this.employeeSurname = employeeSurname;
    }

    public EmployeeStatusEnum getStatus() {
        return status;
    }

    public void setStatus(EmployeeStatusEnum status) { this.status = status; }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getIdBrigade() {
        return idBrigade;
    }

    public void setIdBrigade(Integer idBrigade) { this.idBrigade = idBrigade; }

    public String toString() {
        return "Employee #" + super.getId() + " Name " + employeeName + " Surname " + employeeSurname + " Status " + status.toString().toLowerCase()
                + " Login " + login + " Password " + password + " idBrigade " + idBrigade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return idBrigade == employee.idBrigade && Objects.equals(employeeName, employee.employeeName) && Objects.equals(employeeSurname, employee.employeeSurname) && status == employee.status && Objects.equals(login, employee.login) && Objects.equals(password, employee.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeName, employeeSurname, status, login, password, idBrigade);
    }
}
