package by.gstu.airline.model.Employee.Chief;

import by.gstu.airline.model.Employee.Employee;

public class Chief extends Employee {

    public Chief() {

    }

    public Chief(int id) {
        super();
    }

}
