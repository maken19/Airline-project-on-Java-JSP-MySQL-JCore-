package by.gstu.airline.model.Employee.Chief;

import java.util.Objects;

public class Dispetcher extends Chief {

    private String disName;
    private String disSurname;

    public Dispetcher() {
    }

    public Dispetcher(int id, String disName, String disSurname) {
        super(id);
        this.disName = disName;
        this.disSurname = disSurname;
    }

    public String getDisName() {
        return disName;
    }

    public void setDisName(String disName) {
        this.disName = disName;
    }

    public String getDisSurname() {
        return disSurname;
    }

    public void setDisSurname(String disSurname) { this.disSurname = disSurname; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dispetcher that = (Dispetcher) o;
        return Objects.equals(disName, that.disName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(disName);
    }
}

