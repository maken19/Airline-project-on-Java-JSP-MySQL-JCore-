package by.gstu.airline.model.Employee.Chief;

import java.util.Objects;

public class Administrator extends Chief {

    private String admName;
    private String admSurname;

    public Administrator() {
    }

    public Administrator(int id, String admName, String admSurname) {
        super(id);
        this.admName = admName;
        this.admSurname = admSurname;
    }

    public String getAdmName() {
        return admName;
    }

    public void setAdmName(String admName) {
        this.admName = admName;
    }

    public String getAdmSurname() {
        return admSurname;
    }

    public void setAdmSurname(String admSurname) { this.admSurname = admSurname; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Administrator that = (Administrator) o;
        return Objects.equals(admName, that.admName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(admName);
    }
}
