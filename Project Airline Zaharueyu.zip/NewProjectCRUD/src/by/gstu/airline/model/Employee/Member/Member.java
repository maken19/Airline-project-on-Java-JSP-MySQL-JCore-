package by.gstu.airline.model.Employee.Member;

import by.gstu.airline.model.Employee.Employee;

public class Member extends Employee {

    private String memName;
    private String role;//пилот стюарды штурман радист
}