package by.gstu.airline.model.Trip;

import by.gstu.airline.enumeration.TripStatusEnum;
import by.gstu.airline.model.Entity;

import java.io.Serializable;
import java.sql.Date;
import java.util.Objects;

public class Trip extends Entity implements Serializable {

    private java.sql.Date tripDate;
    private String tripName;
    private TripStatusEnum status;
    private Date tripDates;


    public Trip() {
    }

    public Trip(int id, java.sql.Date tripDate, String tripName, TripStatusEnum status){
        super(id);
        this.tripDate = tripDate;
        this.tripName = tripName;
        this.status = status;
    }

    public Trip(java.sql.Date date, String name, TripStatusEnum waiting) {
        this.tripDates = date;
        this.tripName = name;
        this.status = waiting;
    }

    public java.sql.Date getTripDate() {
        return tripDate;
    }

    public void setTripDate(Date tripDate) {
        this.tripDate = tripDate;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public TripStatusEnum getStatus() {
        return status;
    }

    public void setStatus(TripStatusEnum status) { this.status = status; }

    public String toString() {
        return "Trip #" + super.getId() + " Date " + tripDates.toString() + " Name " + tripName + " Status " + status.toString().toLowerCase();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trip trip = (Trip) o;
        return Objects.equals(tripDate, trip.tripDate) && Objects.equals(tripName, trip.tripName) && status == trip.status;
    }

    @Override
    public int hashCode() {
        return Objects.hash(tripDate, tripName, status);
    }
}
