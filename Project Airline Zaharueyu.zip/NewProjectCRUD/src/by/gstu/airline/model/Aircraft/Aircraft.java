package by.gstu.airline.model.Aircraft;
import by.gstu.airline.enumeration.AircraftStatusEnum;
import by.gstu.airline.model.Entity;

import java.io.Serializable;
import java.util.Objects;

public class Aircraft extends Entity implements Serializable {

    private String aircraftName;
    private AircraftStatusEnum status;
    private double capacity;
    private int idTrip;
    private int idBrigade;

    public Aircraft() {

    }

    public Aircraft(int id, String aircraftName, AircraftStatusEnum status, double capacity, int idTrip, int idBrigade) {
        super(id);
        this.aircraftName = aircraftName;
        this.status = status;
        this.capacity = capacity;
        this.idTrip = idTrip;
        this.idBrigade = idBrigade;
    }
    public Aircraft(String aircraftName, AircraftStatusEnum status, double capacity, int idBrigade){
        this.aircraftName = aircraftName;
        this.status = status;
        this.capacity = capacity;
        this.idTrip = idTrip;
        this.idBrigade = idBrigade;
    }

    public String getAircraftName() {
        return aircraftName;
    }

    public void setAircraftName(String aircraftName) {
        this.aircraftName = aircraftName;
    }

    public AircraftStatusEnum getStatus() {
        return status;
    }

    public void setStatus(AircraftStatusEnum status) { this.status = status; }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) { this.capacity = capacity; }

    public int getIdTrip() {
        return idTrip;
    }

    public void setIdTrip(int idTrip) { this.idTrip = idTrip; }

    public int getIdBrigade() {
        return idBrigade;
    }

    public void setIdBrigade(int idBrigade) { this.idBrigade = idBrigade; }

    public String toString() {
        return "Aircraft #" + super.getId() + " AircraftName " + aircraftName + " Status " + status.toString().toLowerCase() + " Capacity " + capacity + " idTrip " + idTrip + " idBrigade " + idBrigade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Aircraft aircraft = (Aircraft) o;
        return Double.compare(aircraft.capacity, capacity) == 0 && idTrip == aircraft.idTrip && idBrigade == aircraft.idBrigade && Objects.equals(aircraftName, aircraft.aircraftName) && status == aircraft.status;
    }

    @Override
    public int hashCode() {
        return Objects.hash(aircraftName, status, capacity, idTrip, idBrigade);
    }
}
