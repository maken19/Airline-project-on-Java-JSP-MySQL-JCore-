package by.gstu.airline.model.Brigade;

import by.gstu.airline.model.Entity;

import java.io.Serializable;
import java.util.Objects;

public class Brigade extends Entity implements Serializable {

    private String brigadeName;

    public Brigade() {
    }

    public Brigade( int id, String brigadeName) {
            super(id);
            this.brigadeName = brigadeName;
    }

    public String getBrigadeName() {
        return brigadeName;
    }

    public void setBrigadeName(String brigadeName) {
        this.brigadeName = brigadeName;
    }

    public String toString() {
        return "Brigade #" + super.getId() + " BrigadeName " + brigadeName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Brigade brigade = (Brigade) o;
        return Objects.equals(brigadeName, brigade.brigadeName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(brigadeName);
    }
}
