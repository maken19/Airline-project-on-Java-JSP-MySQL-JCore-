package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.model.Trip.Trip;
import by.gstu.airline.util.MappingUtility;
import by.gstu.airline.util.MessageUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

public class ShowAdministratorTripsCommand implements Command {

    private static final Logger logger = LogManager.getLogger();

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_NO_TRIPS = "noTrips";
    private static final String PARAM_NAME_WAITING_TRIPS = "waitingTrips";
    private static final String PARAM_NAME_CONFIRMED_TRIPS = "performedTrips";
    private static final String PARAM_NAME_CLOSED_TRIPS = "doneTrips";
    /**
     * URL, gets from mapping.properties
     */
    private static final String TRIPS_PAGE_PATH = "path.page.administrator.trips";
    private static final String PARAM_NAME_USER = "user";
    /**
     * Messages, which will be print on jsp
     */
    private static final String MESSAGE_NO_TRIPS = "message.no.orders";

    private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private TripDAO tripDAO = mySql.getTripDAO();

    /**
     * Show trips. Trips are sorted by their status.
     *
     * @param request
     * @return - redirect to orders page
     */
    @Override
    public String execute(HttpServletRequest request) {
        String page = null;
        List<Trip> trips = tripDAO.findAll();
        ArrayList<Trip> performedTrips = new ArrayList<>();
        ArrayList<Trip> waitingTrips = new ArrayList<>();
        ArrayList<Trip> doneTrips = new ArrayList<>();
        String clientName = String.valueOf(request.getSession().getAttribute(PARAM_NAME_USER));
        if (trips.size() > 0) {
            for (Trip item : trips) {
                switch (item.getStatus()) {
                    case PERFORMED:
                        performedTrips.add(item);
                        break;
                    case WAITING:
                        waitingTrips.add(item);
                        break;
                    case DONE:
                        doneTrips.add(item);
                        break;
                }
            }

            request.setAttribute(PARAM_NAME_WAITING_TRIPS, waitingTrips);
            request.setAttribute(PARAM_NAME_CLOSED_TRIPS, doneTrips);
            request.setAttribute(PARAM_NAME_CONFIRMED_TRIPS, performedTrips);
        } else {
            request.setAttribute(PARAM_NAME_NO_TRIPS, getMessage(MESSAGE_NO_TRIPS));
        }

        page = MappingUtility.getPath(TRIPS_PAGE_PATH);

        return page;
    }

    private String getMessage(String message) {
        return MessageUtility.getMessage(message);
    }
}
