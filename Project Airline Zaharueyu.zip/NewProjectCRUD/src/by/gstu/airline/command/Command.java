package by.gstu.airline.command;

import javax.servlet.http.HttpServletRequest;

/**
 * Interface for commands
 */
public interface Command {

    String execute(HttpServletRequest request);
}
