package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.model.Aircraft.Aircraft;
import by.gstu.airline.util.MappingUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import by.gstu.airline.util.MessageUtility;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

import static by.gstu.airline.util.MessageUtility.getMessage;

public class ShowAircraftsDispCommand implements Command {

    private static final Logger logger = LogManager.getLogger();

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_NO_AIRCRAFTS = "noOrders";
    private static final String PARAM_NAME_WAITING_AIRCRAFTS = "waitingAircrafts";

    /**
     * URL, gets from mapping.properties
     */
    private static final String WAITING_AIRCRAFTS_PAGE_PATH = "path.page.dispetcher.waiting.aircrafts";

    /**
     * Messages, which will be print on jsp
     */
    private static final String MESSAGE_NO_AIRCRAFTS = "message.no.aircrafts";


    private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private AircraftDAO aircraftDAO = mySql.getAircraftDAO();

    @Override
    public String execute(HttpServletRequest request) {
        String page = null;
        List<Aircraft> aircrafts = aircraftDAO.findAll();
        ArrayList<Aircraft> waitingAircrafts = new ArrayList<>();
        ArrayList<Aircraft> waitingAircraftsWithoutBrig = new ArrayList<>();

        if (aircrafts.size() > 0) {
            for (Aircraft item : aircrafts) {
                switch (item.getStatus()) {
                    case WAITING :
                        waitingAircrafts.add(item);
                        break;
                }
            }
            for (Aircraft item : waitingAircrafts){
                switch (item.getIdBrigade()) {
                    case 0:
                        waitingAircraftsWithoutBrig.add(item);
                        break;
                }
            }
            request.setAttribute(PARAM_NAME_WAITING_AIRCRAFTS, waitingAircraftsWithoutBrig);
        } else {
            request.setAttribute(PARAM_NAME_NO_AIRCRAFTS, getMessage(MESSAGE_NO_AIRCRAFTS));
        }
        page = MappingUtility.getPath(WAITING_AIRCRAFTS_PAGE_PATH);
        return page;
    }

    private String getMessage(String message) {
        return MessageUtility.getMessage(message);
    }
}
