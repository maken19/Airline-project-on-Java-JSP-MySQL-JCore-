package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.BrigadeDAO;
import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.enumeration.EmployeeStatusEnum;
import by.gstu.airline.helper.LoginHelper;
import by.gstu.airline.model.Aircraft.Aircraft;
import by.gstu.airline.model.Brigade.Brigade;
import by.gstu.airline.model.Employee.Employee;
import by.gstu.airline.model.Trip.Trip;
import by.gstu.airline.util.MappingUtility;
import by.gstu.airline.util.MessageUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static by.gstu.airline.helper.LoginHelper.isAdministrator;
import static by.gstu.airline.helper.LoginHelper.isDispetcher;
import static by.gstu.airline.helper.LoginHelper.isMember;

public class LoginCommand implements Command {

    private static final Logger logger = LogManager.getLogger();

    /**
     * URL, gets from mapping.properties
     */
    private static final String MAIN_DISPETCHER_PAGE_PATH = "path.page.main.dispetcher";
    private static final String MAIN_MEMBER_PAGE_PATH = "path.main.member.page";
    private static final String MAIN_ADMINISTRATOR_PAGE_PATH = "path.page.main.administrator";
    private static final String LOGIN_PAGE = "path.page.login";

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_USER = "user";
    private static final String PARAM_NAME_LOGIN_ERROR = "login_error";
    private static final String PARAM_NAME_LOGIN = "login";
    private static final String PARAM_NAME_PASSWORD = "password";
    private static final String PARAM_NAME_AIRCRAFT = "aircrafts";
    private static final String PARAM_NAME_TRIP = "trips";
    /**
     * Messages, which will be print on jsp
     */
    private static final String LOGIN_ERROR = "message.error.login.not.found";
    private static final String MESSAGE_NO_AIRCRAFTS = "message.no.aircrafts";
    private static final String MESSAGE_NO_BRIGADES = "message.no.brigades";
    private static final String MESSAGE_NO_TRIPS = "message.no.brigades";
    private static final String PARAM_NAME_CLIENTS = "clients";
    private static final String PARAM_NAME_EMPLOYEES = "employees";
    private static final String PARAM_NAME_BRIGADE = "brigades";
    private static final String PARAM_NAME_ = "members";


    private DAOFactory mysql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private EmployeeDAO employeeDAO = mysql.getEmployeeDAO();
    private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private AircraftDAO aircraftDao = mySql.getAircraftDAO();
    private EmployeeDAO memberAccounts = mySql.getEmployeeDAO();
    private BrigadeDAO brigadeDAO = mySql.getBrigadeDAO();
    private TripDAO tripDAO = mySql.getTripDAO();
    private BrigadeDAO brigadesDAO = mySql.getBrigadeDAO();
    /**
     * If it's administrator-account, redirect to page main administrator page,
     * if it's dispatcher-account, redirect to page main dispatcher page
     * else redirect to main member page.
     * Create session for this account.
     *
     * @param request
     * @return page - if account exist redirect to page, else prints error message.
     */
    @Override
    public String execute(HttpServletRequest request) {
        String page = null;

        String login = request.getParameter(PARAM_NAME_LOGIN);
        String pass = request.getParameter(PARAM_NAME_PASSWORD);

        if (LoginHelper.getInstance().checkAccount(login, pass)) {
            request.getSession().setAttribute(PARAM_NAME_USER, login);
            final Employee employee =  employeeDAO.findEmployeeByLogin(login);

            if (isAdministrator(employee)) {
                page = MappingUtility.getPath(MAIN_ADMINISTRATOR_PAGE_PATH);
                request.getSession().setAttribute("clientType", EmployeeStatusEnum.ADMINISTRATOR);
                showAircrafts(request);
            } else if (isDispetcher(employee)){
                page = MappingUtility.getPath(MAIN_DISPETCHER_PAGE_PATH);
                request.getSession().setAttribute("clientType", EmployeeStatusEnum.DISPETCHER);
                showBrigades(request);
            }
            else{
                page = MappingUtility.getPath(MAIN_MEMBER_PAGE_PATH);
                request.getSession().setAttribute("clientType", EmployeeStatusEnum.MEMBER);
                Integer idBrigade = employee.getIdBrigade();
                if(idBrigade != null){
                    addMembers(request, idBrigade);
                    addBrigade(request, idBrigade);
                }
            }
            logger.info("User " + login + " log in.");
        } else {
            logger.warn("User isn't logged in.");
            page = MappingUtility.getPath(LOGIN_PAGE);
            request.setAttribute(PARAM_NAME_LOGIN_ERROR, MessageUtility.getMessage(LOGIN_ERROR));
        }

        return page;
    }
    private String getMessage(String message) {
        return MessageUtility.getMessage(message);
    }

    private void showAircrafts(HttpServletRequest request)
    {
        List<Aircraft> aircrafts = aircraftDao.findAll();
        if (aircrafts.size() > 0) {

            request.setAttribute(PARAM_NAME_AIRCRAFT, aircrafts);
        } else request.setAttribute(MESSAGE_NO_AIRCRAFTS, getMessage(MESSAGE_NO_AIRCRAFTS));
    }

    private void showTrips(HttpServletRequest request)
    {
        List<Trip> trips = tripDAO.findAll();
        if (trips.size() > 0) {

            request.setAttribute(PARAM_NAME_TRIP, trips);
        } else request.setAttribute(MESSAGE_NO_TRIPS, getMessage(MESSAGE_NO_TRIPS));
    }

    private void showBrigades(HttpServletRequest request)
    {
        List<Brigade> brigades = brigadesDAO.findAll();
        if (brigades.size() > 0) {

            request.setAttribute(PARAM_NAME_BRIGADE, brigades);
        } else request.setAttribute(MESSAGE_NO_BRIGADES, getMessage(MESSAGE_NO_BRIGADES));
    }

    /*private void showMem(HttpServletRequest request) {
        List<Employee> members = employeeDAO.findAll();
        for (Employee member : members) {
            if (member.getStatus().equals("DISPETCHER") && member.getStatus().equals("ADMINISTRATOR")) {
                members.remove(member);
            }
        }
        request.setAttribute(PARAM_NAME_, members);
    }*/

    private void showMembers(HttpServletRequest request)
    {
        request.setAttribute(PARAM_NAME_CLIENTS, memberAccounts.getAllMembersAccount());
    }
    private void addMembers(HttpServletRequest request, Integer idBrigade)
    {
        request.setAttribute(PARAM_NAME_EMPLOYEES, memberAccounts.findEmployeesByBrigade(idBrigade));
    }
    private void addBrigade(HttpServletRequest request, Integer idBrigade)
    {
        request.setAttribute(PARAM_NAME_BRIGADE, brigadeDAO.findBrigadeById(idBrigade));
    }
}
