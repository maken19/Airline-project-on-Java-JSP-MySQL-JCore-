package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.enumeration.TripStatusEnum;
import by.gstu.airline.model.Trip.Trip;
import by.gstu.airline.util.MappingUtility;
import com.mysql.cj.x.protobuf.MysqlxDatatypes;
import java.text.SimpleDateFormat;
import javax.servlet.http.HttpServletRequest;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class CreateTripCommand implements Command{

    /**
     * URL, gets from mapping.properties
     */
    private static final String TRIPS_PAGE_PATH = "path.page.administrator.trips";

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_DATE = "date";
    private static final String PARAM_NAME_NAME = "name";
    private static final String PARAM_NAME_STATUS = "status";

    /**
     * Messages, which will be print on jsp
     */

    private DAOFactory mysql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private TripDAO tripDAO = mysql.getTripDAO();
    private ShowAdministratorTripsCommand showTrips = new ShowAdministratorTripsCommand();


    public String execute(HttpServletRequest request)
    {
        String page = null;

        Date tripDate = new Date(new java.util.Date().getTime());
        String tripName = request.getParameter(PARAM_NAME_NAME);
        TripStatusEnum status = TripStatusEnum.WAITING;

        Trip trip = new Trip(tripDate, tripName, status);

        tripDAO.create(trip);

        page = showTrips.execute(request);
        //page = MappingUtility.getPath(TRIPS_PAGE_PATH);
        return page;
    }
}
