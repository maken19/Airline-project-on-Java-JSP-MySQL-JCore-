package by.gstu.airline.command;

import by.gstu.airline.util.MappingUtility;

import javax.servlet.http.HttpServletRequest;

public class EmptyCommand implements Command {

    /**
     * URL, gets from mapping.properties
     */
    private static final String LOGIN_PAGE_PATH = "path.page.login";

    /**
     * Executes when command is empty
     *
     * @param request
     * @return page - redirect to login page
     */

    @Override
    public String execute(HttpServletRequest request) {
        return MappingUtility.getInstance().getPath(LOGIN_PAGE_PATH);
    }
}
