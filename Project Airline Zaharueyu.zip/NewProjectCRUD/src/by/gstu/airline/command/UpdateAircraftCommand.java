package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.util.MappingUtility;
import com.mysql.cj.util.StringUtils;

import javax.servlet.http.HttpServletRequest;

public class UpdateAircraftCommand implements Command {

    private static final String ALL_AIRCRAFTS_PAGE = "path.page.aircrafts";
    private AircraftDAO aircraftDAO = DAOFactory.getDAOFactory(DAOFactory.MYSQL).getAircraftDAO();

    @Override
    public String execute(HttpServletRequest request) {
        String aircraftId = request.getParameter("aircraftId");
        if(!StringUtils.isNullOrEmpty(aircraftId)){
            request.setAttribute("aircraft", aircraftDAO.findAircraftById(Integer.parseInt(aircraftId)));
        }

        return MappingUtility.getInstance().getPath(ALL_AIRCRAFTS_PAGE);
    }
}
