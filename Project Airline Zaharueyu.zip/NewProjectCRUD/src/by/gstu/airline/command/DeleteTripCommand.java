package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.enumeration.TripStatusEnum;
import by.gstu.airline.model.Trip.Trip;

import javax.servlet.http.HttpServletRequest;

public class DeleteTripCommand implements Command {

    ShowAdministratorTripsCommand administratorTripsCommand = new ShowAdministratorTripsCommand();

    private DAOFactory mysql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private TripDAO tripDAO = mysql.getTripDAO();

    @Override
    public String execute(HttpServletRequest request) {
        String page=null;
        //Integer tripId = Integer.valueOf(request.getParameter("tripId"));
        //Trip trip = tripDAO.findTripById(Integer.parseInt(tripId));
        tripDAO.delete(Integer.parseInt(request.getParameter("tripId")));

        page=administratorTripsCommand.execute(request);

        return page;
    }
}
