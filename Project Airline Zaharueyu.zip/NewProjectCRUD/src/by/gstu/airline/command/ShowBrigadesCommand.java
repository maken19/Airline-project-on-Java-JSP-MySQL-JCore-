package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.BrigadeDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.util.MappingUtility;

import javax.servlet.http.HttpServletRequest;

public class ShowBrigadesCommand implements Command {

        /**
         * URL, gets from mapping.properties
         */
        private static final String MAIN_DISPETCHER_PAGE_PATH = "path.page.main.dispetcher";

        /**
         * Params from jsp page
         */
        private static final String PARAM_NAME_CLIENTS = "brigades";

        private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
        private BrigadeDAO allBrigades = mySql.getBrigadeDAO();

    @Override
    public String execute(HttpServletRequest request) {
        String page = null;
        request.setAttribute(PARAM_NAME_CLIENTS, allBrigades.findAll());
        page = MappingUtility.getPath(MAIN_DISPETCHER_PAGE_PATH);

        return page;
    }
}
