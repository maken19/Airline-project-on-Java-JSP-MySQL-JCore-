package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.enumeration.AircraftStatusEnum;
import by.gstu.airline.model.Aircraft.Aircraft;
import by.gstu.airline.util.MappingUtility;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static by.gstu.airline.util.MessageUtility.getMessage;

public class CreateAircraftCommand implements Command {

    /**
     * URL, gets from mapping.properties
     */
    private static final String MAIN_ADMINISTRATOR_PAGE_PATH = "path.page.main.administrator";

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_AIRCRAFT = "aircrafts";
    private static final String PARAM_NAME_CAPACITY = "capacity";
    private static final String PARAM_NAME_NAME = "name";
    private static final String PARAM_NAME_STATUS = "status";

    private DAOFactory mysql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private AircraftDAO aircraftDAO = mysql.getAircraftDAO();


    @Override
    public String execute(HttpServletRequest request) {
        String page = null;

        Double capacity = Double.valueOf(request.getParameter(PARAM_NAME_CAPACITY));;
        String aircraftName = request.getParameter(PARAM_NAME_NAME);
        AircraftStatusEnum status = AircraftStatusEnum.WAITING;
        Integer idBrigade = 0;

        Aircraft aircraft = new Aircraft(aircraftName, status, capacity, idBrigade);

        aircraftDAO.create(aircraft);

        List<Aircraft> aircrafts = aircraftDAO.findAll();
        if (aircrafts.size() > 0) {

            request.setAttribute(PARAM_NAME_AIRCRAFT, aircrafts);
        }

        page = MappingUtility.getPath(MAIN_ADMINISTRATOR_PAGE_PATH);
        return page;
    }
}
