package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.AircraftDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.util.MappingUtility;

import javax.servlet.http.HttpServletRequest;

public class ShowaAircraftsCommand implements Command {

    /**
     * URL, gets from mapping.properties
     */
    private static final String MAIN_ADMINISTRATOR_PAGE_PATH = "path.page.main.administrator";

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_AIRCRAFTS = "aircrafts";

   private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
   private AircraftDAO allAircrafts = mySql.getAircraftDAO();

    /**
     * Show all aircrafts to administrator
     *
     * @param request
     * @return page - redirect to main administrator page*/

    @Override
    public String execute(HttpServletRequest request) {
        String page = null;
        request.setAttribute(PARAM_NAME_AIRCRAFTS, allAircrafts.findAll());
       page = MappingUtility.getPath(MAIN_ADMINISTRATOR_PAGE_PATH);

        return page;
   }
}
