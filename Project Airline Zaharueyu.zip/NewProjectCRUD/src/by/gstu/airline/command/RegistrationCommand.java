package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.helper.LoginHelper;
import by.gstu.airline.model.Employee.Employee;
import by.gstu.airline.util.MappingUtility;
import by.gstu.airline.util.MessageUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static by.gstu.airline.helper.LoginHelper.isMember;
import javax.servlet.http.HttpServletRequest;

public class RegistrationCommand implements Command{

    private static final Logger logger = LogManager.getLogger();

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_LOGIN = "login";
    private static final String PARAM_NAME_PASSWORD = "password";
    private static final String PARAM_NAME_YES = "yes";
    private static final String PARAM_NAME_SUCCESS = "registrationComplete";

    /**
     * Params from jsp page, where will be print error messages
     */
    private static final String PARAM_NAME_ERROR_LOGIN = "loginError";
    private static final String PARAM_NAME_ERROR_PASSWORD = "passwordError";
    private static final String PARAM_NAME_ERROR_ACCOUNT_EXIST = "accountExist";

    /**
     * URL, gets from mapping.properties
     */
    private static final String LOGIN_PAGE = "path.page.login";
    private static final String REGISTRATION_PAGE = "path.page.registration";

    /**
     * Messages, which will be print on jsp
     */
    private static final String LOGIN_ERROR = "message.error.login";
    private static final String PASSWORD_ERROR = "message.error.password";
    private static final String ERROR_ACCOUNT_EXIST = "message.error.accountExist";
    private static final String SUCCESS_REGISTRATION = "registration.complete";

    private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private EmployeeDAO employeeDAO = mySql.getEmployeeDAO();

    /**
     * Registration new user
     *
     * @param request
     * @return page - if registration is complete, redirect to login page, else prints error message.
     */
    @Override
    public String execute(HttpServletRequest request) {
        String page = null;

        String login = request.getParameter(PARAM_NAME_LOGIN);
        String pass = request.getParameter(PARAM_NAME_PASSWORD);

        page = MappingUtility.getPath(REGISTRATION_PAGE);
        if (LoginHelper.getInstance().checkLogin(login)) {
            request.setAttribute(PARAM_NAME_ERROR_ACCOUNT_EXIST, getMessage(ERROR_ACCOUNT_EXIST));
            return page;
        }
        if (login.isEmpty()) {
            request.setAttribute(PARAM_NAME_ERROR_LOGIN, getMessage(LOGIN_ERROR));
        } else if (pass.isEmpty()) {
            request.setAttribute(PARAM_NAME_ERROR_PASSWORD, getMessage(PASSWORD_ERROR));
        }  else {
            createAccount(login, pass);
            try {

                logger.info("New user is registered " + login);
                request.setAttribute(PARAM_NAME_SUCCESS, getMessage(SUCCESS_REGISTRATION));
            } catch (NumberFormatException e) {
                logger.error("User isn't registered.");
                logger.error(e.getMessage());

            }
        }
        return page;
    }

    private String getMessage(String message) {
        return MessageUtility.getMessage(message);
    }

    private void createAccount(String login, String password) {
        Employee employee = new Employee();
        employee.setLogin(login);
        employee.setPassword(password);
        employeeDAO.create3(employee);
    }

}
