package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.enumeration.TripStatusEnum;
import by.gstu.airline.model.Trip.Trip;

import javax.servlet.http.HttpServletRequest;

public class CloseCommand implements Command {

    ShowAdministratorTripsCommand administratorTripsCommand = new ShowAdministratorTripsCommand();
    private static final String ORDERS_PAGE_PATH = "path.page.administrator.orders";
    private DAOFactory mysql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private TripDAO tripDAO = mysql.getTripDAO();

    public String execute(HttpServletRequest request)
    {
        String page=null;
        String tripId = request.getParameter("tripId");
        Trip trip = tripDAO.findTripById(Integer.parseInt(tripId));
        trip.setStatus(TripStatusEnum.DONE);
        tripDAO.update(trip);

        page=administratorTripsCommand.execute(request);
        return page;
    }
}
