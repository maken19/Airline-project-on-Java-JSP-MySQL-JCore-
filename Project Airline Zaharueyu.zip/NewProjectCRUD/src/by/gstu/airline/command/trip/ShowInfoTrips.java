package by.gstu.airline.command.trip;

import by.gstu.airline.command.Command;
import by.gstu.airline.connect.DAO.TripDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.util.MappingUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

public class ShowInfoTrips implements Command {

    private static final Logger logger = LogManager.getLogger();

    /**
     * URL, gets from mapping.properties
     */
    private static final String MAIN_DISPATCHER_PAGE_PATH = "path.page.main.dispetcher";

    /**
     * Params from jsp page
     */
    private static final String PARAM_NAME_TRIPS = "trips";

    private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private TripDAO allTrips = mySql.getTripDAO();
    @Override
    public String execute(HttpServletRequest request) {

        String page = null;
        request.setAttribute(PARAM_NAME_TRIPS, allTrips.findAll());
        page = MappingUtility.getInstance().getPath(MAIN_DISPATCHER_PAGE_PATH);
        return page;
    }


}
