package by.gstu.airline.command;

import by.gstu.airline.connect.DAO.EmployeeDAO;
import by.gstu.airline.connect.DAO.factory.DAOFactory;
import by.gstu.airline.model.Employee.Employee;
import by.gstu.airline.util.MappingUtility;
import by.gstu.airline.util.MessageUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public class ShowMembersCommand implements Command{

    private static final Logger logger = LogManager.getLogger();

    private static final String MESSAGE_NO_MEMBERS = "message.no.members";

    private static final String MEMBERS_PAGE_PATH = "path.member.for.dispetcher";

    private static final String PARAM_NAME_MEMBER = "members";

    private DAOFactory mySql = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
    private EmployeeDAO employeeDao = mySql.getEmployeeDAO();

    @Override
    public String execute(HttpServletRequest request) {
        String page = null;
        List<Employee> employees = employeeDao.findAll();
        for (Employee member : employees) {
            if (member.getStatus().equals("DISPETCHER") && member.getStatus().equals("ADMINISTRATOR")) {
                employees.remove(member);
            }
        }
        //employees = employeeDao.getAllMembersAccount();
        if (employees.size() > 0) {

            request.setAttribute(PARAM_NAME_MEMBER, employees);
        } else request.setAttribute(MESSAGE_NO_MEMBERS, getMessage(MESSAGE_NO_MEMBERS));


        page = MappingUtility.getPath(MEMBERS_PAGE_PATH);

        return page;
    }
    private String getMessage(String message) {
        return MessageUtility.getMessage(message);
    }

}
